tccutil reset Photos com.nektony.Duplicate-File-Finder-SIII
tccutil reset All com.nektony.Duplicate-File-Finder-SIII