tccutil reset Reminders com.nektony.Disk-Expert-SIII
tccutil reset Photos com.nektony.Disk-Expert-SIII
tccutil reset All com.nektony.Disk-Expert-SIII