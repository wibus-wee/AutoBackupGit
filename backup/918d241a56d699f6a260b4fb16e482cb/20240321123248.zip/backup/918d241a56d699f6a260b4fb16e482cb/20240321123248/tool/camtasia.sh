tccutil reset Camera com.techsmith.camtasia2023
tccutil reset Microphone com.techsmith.camtasia2023
tccutil reset ScreenCapture com.techsmith.camtasia2023
tccutil reset All com.techsmith.camtasia2023
/usr/bin/codesign -f -s - /Applications/Camtasia\ 2023.app/Contents/Resources/CLExporter
/usr/bin/codesign -f -s - /Applications/Camtasia\ 2023.app/Contents/Resources/CLThumbnailer