tccutil reset All com.xunyong.hapigo
tccutil reset AddressBook com.xunyong.hapigo
tccutil reset Calendar com.xunyong.hapigo
tccutil reset Reminders com.xunyong.hapigo
tccutil reset ScreenCapture com.xunyong.hapigo
tccutil reset Accessibility com.xunyong.hapigo