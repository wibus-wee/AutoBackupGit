# 本教程旨在破解Emby Server for macOS
## 支持版本: 4.7.14.0 
下载地址: https://github.com/MediaBrowser/Emby.Releases/releases/download/4.7.14.0/embyserver-osx-x64-4.7.14.0.zip

## 使用方法
Emby.Web.dll 替换到 /Applications/EmbyServer.app/Contents/MacOS/Emby.Web.dll

embypremiere.js 替换到 /Applications/EmbyServer.app/Contents/Resources/dashboard-ui/embypremiere/embypremiere.js

## 最后
我再说一遍：网上那些破解Emby Linux/Windows Server版本要替换四五个文件的人都是傻狗。

不就是修改个b前端js和改一下.Net资源文件的事情被你们搞这么复杂，老子一直以为这东西很难都懒得弄，没想到就他妈这么点b大点难度。一群饭桶！