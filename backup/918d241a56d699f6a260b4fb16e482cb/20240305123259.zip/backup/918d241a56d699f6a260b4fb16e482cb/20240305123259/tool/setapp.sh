chmod +x tool/optool
tool/optool install -p /Applications/Setapp.app/Contents/Frameworks/libInjectLib.dylib -t /Applications/Setapp.app/Contents/Library/LaunchServices/Setapp.app/Contents/MacOS/SetappAgent  --resign
