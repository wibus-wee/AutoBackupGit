tccutil reset AddressBook com.nektony.App-Cleaner-SIII
tccutil reset Reminders com.nektony.App-Cleaner-SIII
tccutil reset Photos com.nektony.App-Cleaner-SIII
tccutil reset AppleEvents com.nektony.App-Cleaner-SIII
tccutil reset All com.nektony.App-Cleaner-SIII