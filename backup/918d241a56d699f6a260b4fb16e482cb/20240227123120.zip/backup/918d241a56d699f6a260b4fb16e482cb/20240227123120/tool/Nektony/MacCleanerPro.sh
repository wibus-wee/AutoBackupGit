tccutil reset AddressBook com.nektony.MacCleaner-PRO-SIII
tccutil reset Calendar com.nektony.MacCleaner-PRO-SIII
tccutil reset Reminders com.nektony.MacCleaner-PRO-SIII
tccutil reset Photos com.nektony.MacCleaner-PRO-SIII
tccutil reset AppleEvents com.nektony.MacCleaner-PRO-SIII
tccutil reset All com.nektony.MacCleaner-PRO-SIII