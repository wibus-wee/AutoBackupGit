// SPDX-FileCopyrightText: Copyright 2018 yuzu Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#include "core/hle/service/set/setting_formats/private_settings.h"

namespace Service::Set {

PrivateSettings DefaultPrivateSettings() {
    return {};
}

} // namespace Service::Set
